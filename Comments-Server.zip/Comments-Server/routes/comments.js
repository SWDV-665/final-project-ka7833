const express = require("express");
const router = express.Router();
const Comment = require("../models/Comment");


// Create a comment
router.post("/", async(req, res) => {
  console.log("Creating comment item...");

  const comment = new Comment({
    name: req.body.name,
    movieId: req.body.movieId,
    comment: req.body.comment
  });

  try {
    await comment.save();
    res.status(201).json({message: "Successfully added comment"});
  }
  catch (err) {
    res.status(400).json({ message: err.message });
    }
});

module.exports = router;